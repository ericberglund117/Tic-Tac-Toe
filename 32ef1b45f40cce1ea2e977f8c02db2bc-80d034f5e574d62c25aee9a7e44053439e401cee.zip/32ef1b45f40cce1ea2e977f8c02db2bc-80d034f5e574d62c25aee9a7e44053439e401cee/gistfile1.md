# Project Board/Planning for Tic-Tac-Toe Solo Project 

__Assigned: 7/30/2020__

__Due: 8/4/2020 by 9pm__

__6 days__

- Complete wireframe of website
- Complete the following iterations. 

__Things to note__

- A timeout is used after a completed game to reset the board. (win or draw. quick timeout and then reset the game board)

- YOU DO NOT NEED TO DISPLAY EACH INDIVIDUAL WIN BOARD. WE ONLY NEED TO SEE NUMBER OF WINS.

- No need to match colors or icons, but the overall layout should be the same.

- Request code review with mentor

- Use branches for each iteration

- Remember that the game logic exists exclusively in the data model. The DOM simply reflects/displays that data model.

- Link resources in README or PRs

## Iteration 1- day 1

Plan out the HTML layout (colors and icons do not need to match, but overall layout should closely match the demo video)

- Use wireframe as template 
- Don't spend too much time on HTML and basic styling. functionality is most important. 

complete Pull Request Template 

## Iteration 2- day 1

Create the Player class
Create the Game class
Create main.js

## Iteration 3- day 1/2/3 

Make game fully playable without the DOM (manually updating the Game.board data, etc, from your console) to force yourself to think data-model-first

- Focus on js functionality 
- Get code working, but remember to go back refactor after each iteration

## Iteration 4- day 3

Create central game board on the DOM
Connect Game data model to the DOM

## Iteration 5- day 4

Display the Player data in the sidebars
Automatically reset the game board to allow for a new game to be played after the previous game is won

## Iteration 6- day 5

Persist Player data using local storage (number of wins and mini-boards displaying won games should persist across page refreshes)

__Day 6__

- Make sure README is updated. look back at previous project README for proper layout/sections
- Link resources in README or PRs
- Finish styling
- Refactoring/clean up
- Make sure functionality works. 
- See if you can break the game

## Wireframe

![Tic-Tac-Toe-Wireframe](
